var towerimage,tower;
var door,doorImage;
var climber,climberImage;
var ghost,ghostImage;
var spookySound;
function preload (){
 towerimage=loadImage("tower.png"); 
 doorImage = loadImage("door.png");
 climberImage=loadImage("climber.png"); 
  ghostImage=loadImage("ghost-standing.png")
 spookySound=loadSound("spooky.wav")    
}
function setup(){
 createCanvas (600,600); 
 tower=createSprite(300,300) 
  tower.addImage("tower",towerimage)
tower.velocityY=2  
ghost=createSpite()  
  
}
function draw(){
 background(0) 
  if (tower.y>600){
    tower.y=300
  }
 drawSprites(); 
  
}